package MODEL;

public class ProductType {
    private String typeId;
    private String typeName;

    public ProductType() {
    }

    // Getters and Setters
    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
}